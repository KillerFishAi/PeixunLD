export const environment = {
  production: true,
  apiUrl: '' // Relative path when served from same origin
};
